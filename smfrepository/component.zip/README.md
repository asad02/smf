# smf
for smf academy joomla implementation
This is joomla 3.4 component for SMF academy.
How to create joomla component zip file:
Make a zip file including
- admin folder
- site folder
- smf.xml
- initial_script.php

Then install it into joomla.
